<?php 
return[
    'host' => "localhost",
    'name' => "sursum_dfe_communication",
    'user' => "postgres",
    'pass' => "670477",
    'type' => "pgsql",
    'prep' => "1",
    'slog' => "SystemSqlLogService"
];
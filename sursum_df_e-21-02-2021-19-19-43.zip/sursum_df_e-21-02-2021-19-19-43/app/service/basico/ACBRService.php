<?php

class ACBRService
{
    public function __construct($param)
    {
        
    }
    
    public static function myFunction($param)
    {
        
    }
}
